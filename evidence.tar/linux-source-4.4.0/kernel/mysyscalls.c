#include<linux/kernel.h>
#include<linux/syscalls.h>

/*
 * kernel/mysyscalls.c
 *
 * this is a template of the file that is in the kernel and implements
 * the four new system calls: 
 *     my_syslog, rb_ioctl, rb_enqueue, and rb_dequeue
 *
 * author: Jorge Banegas C11929887
 * date: 10/18/17
 *
 */

#include "mysyscalls.h"

#define RINGBUF_SIZE 16

int g_gdebug = 0;
int is_verbose = 0;
int array_size = 0;

struct RingBuf {
	int head ;
	int tail ;
	int is_full ;
	char ringbuf[RINGBUF_SIZE] ;
} ;

struct RingBuf rb ;


asmlinkage long sys_my_syslog(const char * msg) {
	printk(KERN_ALERT "my_syslog: %s\n", msg) ;
	return 0 ;
}

asmlinkage long sys_rb_ioctl(unsigned int op) {
	switch(op){
	int i=0;

		case RB_OP_SIZE:
			return RINGBUF_SIZE ;
		case RB_OP_ISEMPTY:
		{
			if(rb.tail == rb.head)
			{	
				if(rb.is_full == 1)
				return 0;
			
			return 1;
			}
			
			else
				return 0;
		}	
		case RB_OP_ISFULL:
		{
			if(rb.is_full == 1)
				return 1;
			else
				return 0;
		}
		case RB_OP_COUNT:
		{
			int counter = 0;
			
			for(i=0;i<RINGBUF_SIZE;i++)
			{
				if(rb.ringbuf[i] != 0)
				counter++;
			}
			return counter;
		}
		default:
		return 0;
		
	}
}
asmlinkage long sys_rb_enqueue(char c) {
	if(sys_rb_ioctl(RB_OP_ISFULL) == 1)
		return -1;

	if(sys_rb_ioctl(RB_OP_ISFULL) == 0)
	{
		rb.ringbuf[rb.head] = c;
		rb.head = (rb.head+1) % RINGBUF_SIZE;
		if(rb.head == rb.tail)
			rb.is_full = 1;
	}
}

asmlinkage long sys_rb_dequeue(void) {
	int temp = 0;
	
	if(sys_rb_ioctl(RB_OP_ISEMPTY) == 0)	
	{
		temp = rb.ringbuf[rb.tail];
		rb.ringbuf[rb.tail] = 0;
		rb.tail = (rb.tail+1) % RINGBUF_SIZE;
		rb.is_full = 0;
		return temp;
	}
	if(sys_rb_ioctl(RB_OP_ISEMPTY) == 1)
		return -1;
return 0;
}
